=== jado Swiper Gallery Slider ===
Contributors: ja.do
Tags: swiper, frontend gallery slider, image slider, image carousel, swiper slider, swiper carousel, gallery slider, gallery, wordpress gallery
Donate link: http://idangero.us/donate/?for=Swiper%20Donation
Requires at least: 4.2
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin creates automatically Swiper-Slider for WordPress galleries.

== Description ==
Plugin create automatically Swiper-Gallery-Slider for WordPress galleries. Swiper is a great Slider from idangero.us.
This Plugin just transform the WordPress Gallery to an Swiper-Slider. Very simple. No settings.

Swiper - is the free and most modern mobile touch slider with hardware accelerated transitions and amazing native behavior. It is intended to be used in Desktop and mobile websites.


= Features include =

* Fully responsive
* Touch-enabled Navigation.
* Slider Center Mode
* Slider Vertical
* Drag & Drop Order Change


== Installation ==

1. Upload the 'jado-swiper-gallery-slider' folder to the '/wp-content/plugins/' directory.
2. Activate the "jado-swiper-gallery-slider" plugin through the 'Plugins' menu in WordPress.


== Changelog ==


= 1.4 (22-6-2018)=
* Loading scripts optimised

= 1.3 (20-6-2018)=
* Gallery loading on right position in content
* multiple settings added
* uninstall with DB entry delete
* clean up & optimize code

= 1.2 (14-6-2018)=
* Optimized loading of JS + CSS files
* Banner and Icons added

= 1.1 (13-6-2018)=
* Load only on page where 'gallery' exist

= 1.0 (13-6-2018)=
* Initial release