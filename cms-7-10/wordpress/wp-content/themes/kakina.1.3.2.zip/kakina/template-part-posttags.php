<?php if ( has_tag() ) : ?>
	<p class="text-left">
	    <span class="fa fa-tags"></span>
	    <span><?php the_tags(); ?></span>
	</p>
<?php endif; ?>
