<div id="content" class="container masonry-container">
	
	<?php 
	
		do_action('bazaarlite_masonry'); 

		do_action( 'bazaarlite_pagination'); 
	
	?>

</div>