jQuery.noConflict()(function($){

	$( "#tabs.metaboxes" ).tabs();

});